package com.example.mybatisdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
